
import React, { useState, useEffect } from 'react';
import { Game } from '../types';
import { ArrowLeft, Star, Plus, Heart, Share2, Zap, BrainCircuit } from 'lucide-react';
import { getGameSummary, getGameScoreInsight } from '../geminiService';
import ReviewCard from '../components/ReviewCard';
import { MOCK_REVIEWS } from '../mockData';

interface GameDetailViewProps {
  game: Game;
  onBack: () => void;
  isWishlisted: boolean;
  onToggleWishlist: () => void;
}

const GameDetailView: React.FC<GameDetailViewProps> = ({ game, onBack, isWishlisted, onToggleWishlist }) => {
  const [aiSummary, setAiSummary] = useState<string | null>(null);
  const [aiInsight, setAiInsight] = useState<string | null>(null);
  const [isLoadingAi, setIsLoadingAi] = useState(false);

  useEffect(() => {
    const fetchAiInsights = async () => {
      setIsLoadingAi(true);
      const [summary, insight] = await Promise.all([
        getGameSummary(game.title, game.description),
        getGameScoreInsight(game.title, game.rating)
      ]);
      setAiSummary(summary);
      setAiInsight(insight);
      setIsLoadingAi(false);
    };

    fetchAiInsights();
  }, [game]);

  return (
    <div className="relative animate-in fade-in slide-in-from-bottom-4 duration-500 pb-32 bg-[#0a0612] min-h-screen">
      {/* Background Hero */}
      <div className="relative h-[480px] overflow-hidden">
        <img src={game.coverUrl} className="w-full h-full object-cover blur-md opacity-30 scale-110" alt="blur-bg" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0612] via-transparent to-transparent" />
        
        {/* Header Actions */}
        <div className="absolute top-10 left-0 right-0 px-6 flex justify-between items-center z-20">
          <button onClick={onBack} className="w-11 h-11 bg-slate-900/80 backdrop-blur shadow-lg rounded-none border border-slate-800 flex items-center justify-center text-white hover:text-purple-400 transition-colors">
            <ArrowLeft size={22} />
          </button>
          <div className="flex gap-3">
            <button className="w-11 h-11 bg-slate-900/80 backdrop-blur shadow-lg rounded-none border border-slate-800 flex items-center justify-center text-white hover:text-purple-400">
              <Share2 size={18} />
            </button>
            <button 
              onClick={onToggleWishlist}
              className={`w-11 h-11 bg-slate-900/80 backdrop-blur shadow-lg rounded-none border border-slate-800 flex items-center justify-center transition-all ${isWishlisted ? 'text-pink-500' : 'text-white hover:text-pink-500'}`}
            >
              <Heart size={18} className={isWishlisted ? 'fill-pink-500' : ''} />
            </button>
          </div>
        </div>

        {/* Game Title Info */}
        <div className="absolute bottom-10 left-6 right-6 z-10">
          <div className="flex items-end gap-6">
            <img src={game.coverUrl} className="w-36 h-48 rounded-none shadow-2xl border-2 border-slate-800 object-cover" alt={game.title} />
            <div className="flex-1 pb-2">
              <h1 className="text-3xl font-black text-white leading-[1.1] mb-3 tracking-tight uppercase">{game.title}</h1>
              <div className="flex flex-wrap gap-2 mb-4">
                {game.genre.map(g => (
                  <span key={g} className="text-[10px] font-black uppercase tracking-widest bg-purple-600 text-white px-3 py-1 rounded-none shadow-sm">
                    {g}
                  </span>
                ))}
              </div>
              <div className="flex items-center gap-4 text-slate-400">
                <div className="flex items-center gap-1.5">
                  <Star size={18} className="fill-yellow-500 text-yellow-500" />
                  <span className="text-lg font-black text-white">{game.rating}</span>
                </div>
                <div className="w-1 h-1 rounded-none bg-slate-800" />
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">{game.developer}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="px-6 pt-6 space-y-10">
        {/* Main Stats Bar */}
        <div className="grid grid-cols-3 gap-4 bg-slate-900/40 border border-slate-800 rounded-none p-6 shadow-sm">
          <div className="text-center border-r border-slate-800">
             <p className="text-slate-500 text-[10px] font-black uppercase mb-1 tracking-widest">Year</p>
             <p className="text-white text-sm font-black">{new Date(game.releaseDate).getFullYear()}</p>
          </div>
          <div className="text-center border-r border-slate-800">
             <p className="text-slate-500 text-[10px] font-black uppercase mb-1 tracking-widest">Players</p>
             <p className="text-white text-sm font-black">12.4K</p>
          </div>
          <div className="text-center">
             <p className="text-slate-500 text-[10px] font-black uppercase mb-1 tracking-widest">Studio</p>
             <p className="text-white text-sm font-black truncate px-1">{game.developer.split(' ')[0]}</p>
          </div>
        </div>

        {/* AI Insight Box */}
        <div className="bg-gradient-to-br from-purple-900/20 to-slate-900 border border-purple-900/30 rounded-none p-6 relative overflow-hidden shadow-sm">
          <div className="absolute -top-4 -right-4 p-3 opacity-5">
            <BrainCircuit size={80} className="text-purple-600" />
          </div>
          <div className="flex items-center gap-2 mb-4">
            <Zap size={18} className="text-purple-400 fill-purple-400" />
            <h3 className="text-xs font-black text-purple-400 uppercase tracking-widest">Journyx Verdict</h3>
          </div>
          {isLoadingAi ? (
            <div className="space-y-3 animate-pulse">
              <div className="h-3 w-full bg-purple-900/20 rounded-none" />
              <div className="h-3 w-3/4 bg-purple-900/20 rounded-none" />
            </div>
          ) : (
            <>
              <p className="text-slate-100 text-sm italic font-black leading-relaxed mb-4">
                "{aiInsight}"
              </p>
              <div className="text-xs text-slate-400 leading-relaxed font-medium">
                {aiSummary}
              </div>
            </>
          )}
        </div>

        {/* Description */}
        <section>
          <h3 className="text-xl font-black text-white mb-4 uppercase tracking-tight">About</h3>
          <p className="text-slate-400 text-sm leading-relaxed font-medium">
            {game.description}
          </p>
        </section>

        {/* Community Reviews Section */}
        <section>
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-xl font-black text-white uppercase tracking-tight">Community</h3>
            <button className="text-[10px] font-black text-purple-400 bg-slate-900 px-5 py-2.5 rounded-none border border-slate-800 shadow-sm flex items-center gap-2 uppercase tracking-widest">
              <Plus size={16} /> Write Review
            </button>
          </div>
          <div className="space-y-4">
             {MOCK_REVIEWS.filter(r => r.gameId === game.id).length > 0 ? (
               MOCK_REVIEWS.filter(r => r.gameId === game.id).map(r => <ReviewCard key={r.id} review={r} />)
             ) : (
               <div className="text-center py-16 bg-slate-900/20 rounded-none border border-slate-800 border-dashed">
                  <p className="text-slate-500 text-sm font-bold">No community stories yet.</p>
               </div>
             )}
          </div>
        </section>
      </div>
      
      {/* Bottom Sticky Action */}
      <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-md p-6 z-50 pointer-events-none">
        <div className="flex gap-4 pointer-events-auto">
          <button 
            onClick={onToggleWishlist}
            className={`flex-1 ${isWishlisted ? 'bg-pink-900/40 text-pink-500 border-2 border-pink-900/50' : 'bg-purple-600 text-white shadow-2xl shadow-purple-900/40'} font-black py-5 rounded-none hover:scale-[1.02] active:scale-95 transition-all text-xs uppercase tracking-[0.2em]`}
          >
            {isWishlisted ? 'In Wishlist' : 'Add to Journey'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default GameDetailView;