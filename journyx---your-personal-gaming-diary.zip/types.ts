
export interface Game {
  id: string;
  title: string;
  coverUrl: string;
  rating: number;
  releaseDate: string;
  genre: string[];
  platform: string[];
  description: string;
  developer: string;
  // User-specific stats
  timePlayed?: string;
  trophiesCount?: number;
  totalTrophies?: number;
  // Unique genre stats
  kdRatio?: number;
  timeInFirst?: string;
}

export interface Review {
  id: string;
  gameId: string;
  userId: string;
  userName: string;
  userAvatar: string;
  rating: number;
  content: string;
  date: string;
  likes: number;
  commentsCount: number;
}

export interface User {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  bio: string;
  stats: {
    reviews: number;
    followers: number;
    following: number;
    gamesPlayed: number;
  };
}

export type ViewType = 'home' | 'search' | 'profile' | 'game-detail' | 'notifications';
